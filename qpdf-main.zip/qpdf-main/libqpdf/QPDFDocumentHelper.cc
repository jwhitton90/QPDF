#include <qpdf/QPDFDocumentHelper.hh>

QPDFDocumentHelper::~QPDFDocumentHelper() // NOLINT (modernize-use-equals-default)
{
    // Must be explicit and not inline -- see QPDF_DLL_CLASS in README-maintainer
}
