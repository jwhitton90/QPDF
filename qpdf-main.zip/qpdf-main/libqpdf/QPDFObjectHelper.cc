#include <qpdf/QPDFObjectHelper.hh>

QPDFObjectHelper::~QPDFObjectHelper() // NOLINT (modernize-use-equals-default)
{
    // Must be explicit and not inline -- see QPDF_DLL_CLASS in README-maintainer
}
