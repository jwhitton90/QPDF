ico file created with
```
inkscape -o /tmp/qpdf-tmp.png -w 256 -b white qpdf.svg
convert /tmp/qpdf-tmp.png qpdf.ico
```
