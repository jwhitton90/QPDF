.. _download:

Downloading qpdf
================

qpdf is included in most Linux distributions. Native packages are
available for many other operating systems as well.

Other resources:

- `GitHub release page <https://github.com/qpdf/qpdf/releases/>`__

- `GitHub project <https://github.com/qpdf/qpdf>`__

- `qpdf project web site <https://qpdf.sourceforge.io>`__
